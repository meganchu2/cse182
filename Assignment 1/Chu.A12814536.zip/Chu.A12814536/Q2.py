# Megan Chu
# PID: A12814536
# Assignment 1
# 4/10/18

print("Running Q2...")
print("Hello Bioinformatics")
