# Megan Chu
# PID: A12814536
# Assignment 1
# 4/10/18

# I, Megan Chu, have read the Academic Integrity Policy, Grading Policy, 
# and Syllabus for BENG/BIMM/CSE 182 and agree to them.

print("Printing Q1 note...")
print("I, Megan Chu, have read the Academic Integrity Policy, Grading Policy, ")
print("and Syllabus for BENG/BIMM/CSE 182 and agree to them.")
