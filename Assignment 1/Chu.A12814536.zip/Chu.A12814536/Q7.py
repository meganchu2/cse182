# Megan Chu
# PID: A12814536
# Assignment 1
# 4/10/18

# I spent around 12 hours total setting up python, learning basic
# python for the assignment, and doing the problems.  The actual
# assignment took around 5 hours to code and package for submission.  
# I posted on piazza for clarification about the Q3 header, but did
# not ask anyone else for help.

print("Printing Q7 answer...")
print("I spent around 12 hours total setting up python, learning basic ")
print("python for the assignment, and doing the problems.  The actual ")
print("assignment took around 5 hours to code and package for submission.  ")
print("I posted on piazza for clarification about the Q3 header, but did ")
print("not ask anyone else for help.")
