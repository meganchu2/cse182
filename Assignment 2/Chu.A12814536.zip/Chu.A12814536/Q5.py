# Megan Chu
# PID: A12814536
# Assignment 2
# 4/25/18

# I used python for the assignment, and I used R to plot the graphs.
# I spent around 12 hours on the assignment.  I did not discuss my 
# homework with anyone, but I did look at other peoples' questions on 
# piazza for clarifications on the homework instructions.

print("Printing Q5 answer...")
print("I used python for the assignment, and I used R to plot the graphs.  ")
print("I spent around 12 hours on the assignment.  I did not discuss my ")
print("homework with anyone, but I did look at other peoples' questions on ")
print("piazza for clarifications on the homework instructions.")
